## Springboot - Keycloak 연동
```

- keycloak 연동을 위한 최소한의 파일들만 추가해 놓았습니다.
    (로그인, 로그아웃 확인을 위한 main 페이지 하나만 임시로 만들어 놓았습니다)
    
- 현재 사내 keycloak 서버 (172.30.1.54:8080)의 resource-server3 클라이언트에 연결되어 있습니다.

```

## 테스트 계정
```

ID = external-admin
PW = 0000

```
